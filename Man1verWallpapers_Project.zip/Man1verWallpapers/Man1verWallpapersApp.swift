import SwiftUI

@main
struct Man1verWallpapersApp: App {
    @StateObject private var library = WallpaperLibrary()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(library)
                .preferredColorScheme(.light)
        }
    }
}
