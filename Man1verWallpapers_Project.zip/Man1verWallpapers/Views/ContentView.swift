import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var library: WallpaperLibrary
    @State private var showingImporter = false
    @State private var selectedFilter: WallpaperFileType?
    @State private var selectedItem: WallpaperItem?

    private var visibleItems: [WallpaperItem] {
        guard let selectedFilter else { return library.items }
        return library.items.filter { $0.fileType == selectedFilter }
    }

    var body: some View {
        NavigationStack {
            Group {
                if visibleItems.isEmpty {
                    emptyState
                } else {
                    List {
                        Section {
                            ForEach(visibleItems) { item in
                                Button {
                                    selectedItem = item
                                } label: {
                                    WallpaperRow(item: item)
                                }
                                .buttonStyle(.plain)
                                .swipeActions {
                                    Button(role: .destructive) {
                                        library.delete(item)
                                    } label: {
                                        Label("Удалить", systemImage: "trash")
                                    }
                                }
                            }
                        } header: {
                            Text(selectedFilter?.title ?? "Моя библиотека")
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Man1verWallpapers")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button("Все файлы", systemImage: "square.grid.2x2") {
                            selectedFilter = nil
                        }
                        ForEach(WallpaperFileType.allCases) { type in
                            Button(type.title, systemImage: type.symbol) {
                                selectedFilter = type
                            }
                        }
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                    }
                    .accessibilityLabel("Фильтр файлов")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingImporter = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Импортировать файл")
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [.item],
                allowsMultipleSelection: true
            ) { result in
                switch result {
                case .success(let urls):
                    urls.forEach { library.importFile(from: $0) }
                case .failure(let error):
                    library.errorMessage = "Импорт отменён или не удался: \(error.localizedDescription)"
                }
            }
            .sheet(item: $selectedItem) { item in
                WallpaperDetailView(item: item)
                    .environmentObject(library)
            }
            .alert("Сообщение", isPresented: Binding(
                get: { library.errorMessage != nil },
                set: { if !$0 { library.errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { library.errorMessage = nil }
            } message: {
                Text(library.errorMessage ?? "")
            }
        }
    }

    private var emptyState: some View {
        ContentUnavailableView {
            Label("Ваша библиотека пока пуста", systemImage: "photo.on.rectangle.angled")
        } description: {
            Text("Импортируйте .tendies, .passthm, изображения или видео из приложения «Файлы».")
        } actions: {
            Button("Импортировать файлы") {
                showingImporter = true
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

private struct WallpaperRow: View {
    let item: WallpaperItem

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: item.fileType.symbol)
                .font(.title2)
                .foregroundStyle(.primary)
                .frame(width: 46, height: 46)
                .background(.quaternary, in: RoundedRectangle(cornerRadius: 12))

            VStack(alignment: .leading, spacing: 4) {
                Text(item.filename)
                    .font(.body.weight(.medium))
                    .lineLimit(1)
                Text("\(item.fileType.title) · \(ByteCountFormatter.string(fromByteCount: item.fileSize, countStyle: .file))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
    }
}
