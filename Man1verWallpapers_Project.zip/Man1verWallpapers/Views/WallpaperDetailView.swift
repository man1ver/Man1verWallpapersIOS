import SwiftUI
import AVKit

struct WallpaperDetailView: View {
    @EnvironmentObject private var library: WallpaperLibrary
    @Environment(\.dismiss) private var dismiss
    let item: WallpaperItem

    @State private var shareURL: URL?
    @State private var showShareSheet = false

    private var url: URL { library.fileURL(for: item) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    preview
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 220)
                        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))

                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.filename)
                            .font(.title3.weight(.semibold))
                            .textSelection(.enabled)
                        Label(item.fileType.title, systemImage: item.fileType.symbol)
                            .foregroundStyle(.secondary)
                        Label(ByteCountFormatter.string(fromByteCount: item.fileSize, countStyle: .file), systemImage: "doc")
                            .foregroundStyle(.secondary)
                        Label(item.importedAt.formatted(date: .abbreviated, time: .shortened), systemImage: "calendar")
                            .foregroundStyle(.secondary)
                    }

                    if item.fileType == .tendies || item.fileType == .passthm {
                        ContentUnavailableView(
                            "Пользовательский формат",
                            systemImage: "doc.questionmark",
                            description: Text("Файл сохранён в библиотеке. Формат не распознаётся iOS как системный формат обоев, поэтому приложение не устанавливает его автоматически.")
                        )
                        .frame(minHeight: 170)
                    }

                    Button {
                        shareURL = url
                        showShareSheet = true
                    } label: {
                        Label("Экспортировать файл", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            }
            .navigationTitle("Файл")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Готово") { dismiss() }
                }
            }
            .sheet(isPresented: $showShareSheet) {
                if let shareURL {
                    ShareSheet(activityItems: [shareURL])
                        .presentationDetents([.medium, .large])
                }
            }
        }
    }

    @ViewBuilder
    private var preview: some View {
        switch item.fileType {
        case .image:
            if let image = UIImage(contentsOfFile: url.path) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(8)
            } else {
                unavailablePreview
            }
        case .video:
            VideoPreview(url: url)
                .clipShape(RoundedRectangle(cornerRadius: 20))
        default:
            VStack(spacing: 12) {
                Image(systemName: item.fileType.symbol)
                    .font(.system(size: 52, weight: .light))
                Text(item.fileType.title)
                    .font(.headline)
                Text("Предпросмотр для этого типа файла недоступен")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(24)
        }
    }

    private var unavailablePreview: some View {
        ContentUnavailableView("Предпросмотр недоступен", systemImage: "photo")
    }
}

private struct VideoPreview: View {
    let url: URL

    var body: some View {
        VideoPlayer(player: AVPlayer(url: url))
            .frame(minHeight: 240)
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
