import Foundation
import SwiftUI

@MainActor
final class WallpaperLibrary: ObservableObject {
    @Published private(set) var items: [WallpaperItem] = []
    @Published var errorMessage: String?

    private let metadataFilename = "library.json"

    private var libraryURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Man1verWallpapers", isDirectory: true)
    }

    private var metadataURL: URL {
        libraryURL.appendingPathComponent(metadataFilename)
    }

    init() {
        do {
            try FileManager.default.createDirectory(at: libraryURL, withIntermediateDirectories: true)
            loadMetadata()
        } catch {
            errorMessage = "Не удалось открыть локальную библиотеку: \(error.localizedDescription)"
        }
    }

    func fileURL(for item: WallpaperItem) -> URL {
        libraryURL.appendingPathComponent(item.storedFilename)
    }

    func importFile(from sourceURL: URL) {
        let didAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess { sourceURL.stopAccessingSecurityScopedResource() }
        }

        do {
            let originalName = sourceURL.lastPathComponent
            let storedName = "\(UUID().uuidString)_\(originalName)"
            let destination = libraryURL.appendingPathComponent(storedName)
            try FileManager.default.copyItem(at: sourceURL, to: destination)

            let values = try destination.resourceValues(forKeys: [.fileSizeKey])
            let item = WallpaperItem(
                filename: originalName,
                storedFilename: storedName,
                fileType: WallpaperFileType.classify(url: sourceURL),
                fileSize: Int64(values.fileSize ?? 0)
            )
            items.insert(item, at: 0)
            try saveMetadata()
        } catch {
            errorMessage = "Не удалось импортировать файл: \(error.localizedDescription)"
        }
    }

    func delete(_ item: WallpaperItem) {
        do {
            try FileManager.default.removeItem(at: fileURL(for: item))
            items.removeAll { $0.id == item.id }
            try saveMetadata()
        } catch {
            errorMessage = "Не удалось удалить файл: \(error.localizedDescription)"
        }
    }

    private func loadMetadata() {
        guard FileManager.default.fileExists(atPath: metadataURL.path) else { return }
        do {
            let data = try Data(contentsOf: metadataURL)
            items = try JSONDecoder().decode([WallpaperItem].self, from: data)
                .filter { FileManager.default.fileExists(atPath: fileURL(for: $0).path) }
                .sorted { $0.importedAt > $1.importedAt }
        } catch {
            errorMessage = "Не удалось прочитать каталог файлов: \(error.localizedDescription)"
        }
    }

    private func saveMetadata() throws {
        let data = try JSONEncoder().encode(items)
        try data.write(to: metadataURL, options: .atomic)
    }
}
