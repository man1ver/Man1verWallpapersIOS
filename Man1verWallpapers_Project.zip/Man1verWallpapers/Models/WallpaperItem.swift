import Foundation

enum WallpaperFileType: String, CaseIterable, Identifiable {
    case tendies = "tendies"
    case passthm = "passthm"
    case image = "image"
    case video = "video"
    case other = "other"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .tendies: return ".tendies"
        case .passthm: return ".passthm"
        case .image: return "Изображение"
        case .video: return "Видео"
        case .other: return "Другой файл"
        }
    }

    var symbol: String {
        switch self {
        case .tendies: return "sparkles.rectangle.stack"
        case .passthm: return "lock.rectangle"
        case .image: return "photo"
        case .video: return "video"
        case .other: return "doc"
        }
    }

    static func classify(url: URL) -> WallpaperFileType {
        switch url.pathExtension.lowercased() {
        case "tendies": return .tendies
        case "passthm": return .passthm
        case "jpg", "jpeg", "png", "heic", "heif", "webp": return .image
        case "mov", "mp4", "m4v": return .video
        default: return .other
        }
    }
}

struct WallpaperItem: Identifiable, Codable, Hashable {
    let id: UUID
    let filename: String
    let storedFilename: String
    let fileType: WallpaperFileType
    let importedAt: Date
    let fileSize: Int64

    init(filename: String, storedFilename: String, fileType: WallpaperFileType, importedAt: Date = .now, fileSize: Int64) {
        self.id = UUID()
        self.filename = filename
        self.storedFilename = storedFilename
        self.fileType = fileType
        self.importedAt = importedAt
        self.fileSize = fileSize
    }
}
